/*Dilara TOSUN - 20050111041*/

import java.util.*;
class SinglyLinkedList<E> implements Cloneable {
    private static class Node<E> {
        private final E element;            // reference to the element stored at this node
        private Node<E> next;         // reference to the subsequent node in the list
        public Node(E e, Node<E> n) {
            element = e;
            next = n;
        }
        public E getElement() { return element; }
        public Node<E> getNext() { return next; }
        public void setNext(Node<E> n) { next = n; }
    } //----------- end of nested Node class -----------
    private Node<E> head = null;               // head node of the list (or null if empty)
    private Node<E> tail = null;               // last node of the list (or null if empty)
    private int size = 0;                      // number of nodes in the list
    public SinglyLinkedList() { }              // constructs an initially empty list
    public int size() { return size; }
    public boolean isEmpty() { return size == 0; }
    public E first() {             // returns (but does not remove) the first element
        if (isEmpty()) return null;
        return head.getElement();
    }
    public E last() {              // returns (but does not remove) the last element
        if (isEmpty()) return null;
        return tail.getElement();
    }
    public void addFirst(E e) {                // adds element e to the front of the list
        head = new Node<>(e, head);              // create and link a new node
        if (size == 0)
            tail = head;                           // special case: new node becomes tail also
        size++;
    }
    public void addLast(E e) {                 // adds element e to the end of the list
        Node<E> newest = new Node<>(e, null);    // node will eventually be the tail
        if (isEmpty())
            head = newest;                         // special case: previously empty list
        else
            tail.setNext(newest);                  // new node after existing tail
        tail = newest;                           // new node becomes the tail
        size++;
    }
    public E removeFirst() {                   // removes and returns the first element
        if (isEmpty()) return null;              // nothing to remove
        E answer = head.getElement();
        head = head.getNext();                   // will become null if list had only one node
        size--;
        if (size == 0)
            tail = null;                           // special case as list is now empty
        return answer;
    }

    @SuppressWarnings({"unchecked"})
    public boolean equals(Object o) {
        if (o == null) return false;
        if (getClass() != o.getClass()) return false;
        SinglyLinkedList other = (SinglyLinkedList) o;   // use nonparameterized type
        if (size != other.size) return false;
        Node walkA = head;                               // traverse the primary list
        Node walkB = other.head;                         // traverse the secondary list
        while (walkA != null) {
            if (!walkA.getElement().equals(walkB.getElement())) return false; //mismatch
            walkA = walkA.getNext();
            walkB = walkB.getNext();
        }
        return true;   // if we reach this, everything matched successfully
    }

    @SuppressWarnings({"unchecked"})
    public SinglyLinkedList<E> clone() throws CloneNotSupportedException {
        // always use inherited Object.clone() to create the initial copy
        SinglyLinkedList<E> other = (SinglyLinkedList<E>) super.clone(); // safe cast
        if (size > 0) {                    // we need independent chain of nodes
            other.head = new Node<>(head.getElement(), null);
            Node<E> walk = head.getNext();      // walk through remainder of original list
            Node<E> otherTail = other.head;     // remember most recently created node
            while (walk != null) {              // make a new node storing same element
                Node<E> newest = new Node<>(walk.getElement(), null);
                otherTail.setNext(newest);     // link previous node to this one
                otherTail = newest;
                walk = walk.getNext();
            }
        }
        return other;
    }

    public int hashCode() {
        int h = 0;
        for (Node walk=head; walk != null; walk = walk.getNext()) {
            h ^= walk.getElement().hashCode();      // bitwise exclusive-or with element's code
            h = (h << 5) | (h >>> 27);              // 5-bit cyclic shift of composite code
        }
        return h;
    }
    public String toString() {
        StringBuilder sb = new StringBuilder("(");
        Node<E> walk = head;
        while (walk != null) {
            sb.append(walk.getElement());
            if (walk != tail)
                sb.append(", ");
            walk = walk.getNext();
        }
        sb.append(")");
        return sb.toString();
    }
}
interface Position<E> {
    E getElement() throws IllegalStateException;
}
interface Tree<E> extends Iterable<E> {
    Position<E> root();
    Position<E> parent(Position<E> p) throws IllegalArgumentException;
    Iterable<Position<E>> children(Position<E> p)
            throws IllegalArgumentException;
    int numChildren(Position<E> p) throws IllegalArgumentException;
    boolean isInternal(Position<E> p) throws IllegalArgumentException;
    boolean isExternal(Position<E> p) throws IllegalArgumentException;
    boolean isRoot(Position<E> p) throws IllegalArgumentException;
    int size();
    boolean isEmpty();
    Iterator<E> iterator();
    Iterable<Position<E>> positions();
}
interface Queue<E> {
    int size();
    boolean isEmpty();
    void enqueue(E e);
    E first();
    E dequeue();
}
abstract class AbstractBinaryTree<E> extends AbstractTree<E> implements BinaryTree<E> {
    @Override
    public Position<E> sibling(Position<E> p) {
        Position<E> parent = parent(p);
        if (parent == null) return null;                  // p must be the root
        if (p == left(parent))                            // p is a left child
            return right(parent);                           // (right child might be null)
        else                                              // p is a right child
            return left(parent);                            // (left child might be null)
    }
    @Override
    public int numChildren(Position<E> p) {
        int count=0;
        if (left(p) != null)
            count++;
        if (right(p) != null)
            count++;
        return count;
    }
    @Override
    public Iterable<Position<E>> children(Position<E> p) {
        List<Position<E>> snapshot = new ArrayList<>(2);    // max capacity of 2
        if (left(p) != null)
            snapshot.add(left(p));
        if (right(p) != null)
            snapshot.add(right(p));
        return snapshot;
    }
    private void inorderSubtree(Position<E> p, List<Position<E>> snapshot) {
        if (left(p) != null)
            inorderSubtree(left(p), snapshot);
        snapshot.add(p);
        if (right(p) != null)
            inorderSubtree(right(p), snapshot);
    }
    public Iterable<Position<E>> inorder() {
        List<Position<E>> snapshot = new ArrayList<>();
        if (!isEmpty())
            inorderSubtree(root(), snapshot);   // fill the snapshot recursively
        return snapshot;
    }
    @Override
    public Iterable<Position<E>> positions() {
        return inorder();
    }
}
interface BinaryTree<E> extends Tree<E> {
    Position<E> left(Position<E> p) throws IllegalArgumentException;
    Position<E> right(Position<E> p) throws IllegalArgumentException;
    Position<E> sibling(Position<E> p) throws IllegalArgumentException;
}
abstract class AbstractTree<E> implements Tree<E> {
    @Override
    public boolean isInternal(Position<E> p) { return numChildren(p) > 0; }
    @Override
    public boolean isExternal(Position<E> p) { return numChildren(p) == 0; }
    @Override
    public boolean isRoot(Position<E> p) { return p == root(); }
    @Override
    public int numChildren(Position<E> p) {
        int count=0;
        for (Position child : children(p)) count++;
        return count;
    }
    @Override
    public int size() {
        int count=0;
        for (Position p : positions()) count++;
        return count;
    }
    @Override
    public boolean isEmpty() { return size() == 0; }
    public int depth(Position<E> p) throws IllegalArgumentException {
        if (isRoot(p))
            return 0;
        else
            return 1 + depth(parent(p));
    }
    private int heightBad() {             // works, but quadratic worst-case time
        int h = 0;
        for (Position<E> p : positions())
            if (isExternal(p))                // only consider leaf positions
                h = Math.max(h, depth(p));
        return h;
    }
    public int height(Position<E> p) throws IllegalArgumentException {
        int h = 0;                          // base case if p is external
        for (Position<E> c : children(p))
            h = Math.max(h, 1 + height(c));
        return h;
    }
    private class ElementIterator implements Iterator<E> {
        Iterator<Position<E>> posIterator = positions().iterator();
        public boolean hasNext() { return posIterator.hasNext(); }
        public E next() { return posIterator.next().getElement(); } // return element!
        public void remove() { posIterator.remove(); }
    }
    @Override
    public Iterator<E> iterator() { return new ElementIterator(); }
    @Override
    public Iterable<Position<E>> positions() { return preorder(); }
    private void preorderSubtree(Position<E> p, List<Position<E>> snapshot) {
        snapshot.add(p);                       // for preorder, we add position p before exploring subtrees
        for (Position<E> c : children(p))
            preorderSubtree(c, snapshot);
    }
    public Iterable<Position<E>> preorder() {
        List<Position<E>> snapshot = new ArrayList<>();
        if (!isEmpty())
            preorderSubtree(root(), snapshot);   // fill the snapshot recursively
        return snapshot;
    }
    private void postorderSubtree(Position<E> p, List<Position<E>> snapshot) {
        for (Position<E> c : children(p))
            postorderSubtree(c, snapshot);
        snapshot.add(p);                       // for postorder, we add position p after exploring subtrees
    }
    public Iterable<Position<E>> postorder() {
        List<Position<E>> snapshot = new ArrayList<>();
        if (!isEmpty())
            postorderSubtree(root(), snapshot);   // fill the snapshot recursively
        return snapshot;
    }
    public Iterable<Position<E>> breadthfirst() {
        List<Position<E>> snapshot = new ArrayList<>();
        if (!isEmpty()) {
            Queue<Position<E>> fringe = new LinkedQueue<>();
            fringe.enqueue(root());                 // start with the root
            while (!fringe.isEmpty()) {
                Position<E> p = fringe.dequeue();     // remove from front of the queue
                snapshot.add(p);                      // report this position
                for (Position<E> c : children(p))
                    fringe.enqueue(c);                  // add children to back of queue
            }
        }
        return snapshot;
    }
}
class LinkedQueue<E> implements Queue<E> {
    private final SinglyLinkedList<E> list = new SinglyLinkedList<>();   // an empty  list
    public LinkedQueue() { }                  // new queue relies on the initially empty list
    @Override
    public int size() { return list.size(); }
    @Override
    public boolean isEmpty() { return list.isEmpty(); }
    @Override
    public void enqueue(E element) { list.addLast(element); }
    @Override
    public E first() { return list.first(); }
    @Override
    public E dequeue() { return list.removeFirst(); }
    public String toString() {
        return list.toString();
    }
}
class LinkedBinaryTree<E> extends AbstractBinaryTree<E> {
    protected static class Node<E> implements Position<E> {
        private E element;          // an element stored at this node
        private Node<E> parent;     // a reference to the parent node (if any)
        private Node<E> left;       // a reference to the left child (if any)
        private Node<E> right;      // a reference to the right child (if any)
        public Node(E e, Node<E> above, Node<E> leftChild, Node<E> rightChild) {
            element = e;
            parent = above;
            left = leftChild;
            right = rightChild;
        }

        // accessor methods
        public E getElement() { return element; }
        public Node<E> getParent() { return parent; }
        public Node<E> getLeft() { return left; }
        public Node<E> getRight() { return right; }

        // update methods
        public void setElement(E e) { element = e; }
        public void setParent(Node<E> parentNode) { parent = parentNode; }
        public void setLeft(Node<E> leftChild) { left = leftChild; }
        public void setRight(Node<E> rightChild) { right = rightChild; }
    }
    protected Node<E> createNode(E e, Node<E> parent,
                                 Node<E> left, Node<E> right) {
        return new Node<E>(e, parent, left, right);
    }
    protected Node<E> root = null;     // root of the tree
    private int size = 0;              // number of nodes in the tree
    public LinkedBinaryTree() { }      // constructs an empty binary tree
    protected Node<E> validate(Position<E> p) throws IllegalArgumentException {
        if (!(p instanceof Node<E> node))
            throw new IllegalArgumentException("Not valid position type");
        // safe cast
        if (node.getParent() == node)     // our convention for defunct node
            throw new IllegalArgumentException("p is no longer in the tree");
        return node;
    }
    @Override
    public int size() {return size;}
    @Override
    public Position<E> root() {return root;}
    @Override
    public Position<E> parent(Position<E> p) throws IllegalArgumentException {
        Node<E> node = validate(p);
        return node.getParent();
    }
    @Override
    public Position<E> left(Position<E> p) throws IllegalArgumentException {
        Node<E> node = validate(p);
        return node.getLeft();
    }
    @Override
    public Position<E> right(Position<E> p) throws IllegalArgumentException {
        Node<E> node = validate(p);
        return node.getRight();
    }
    public Position<E> addRoot(E e) throws IllegalStateException {
        if (!isEmpty()) throw new IllegalStateException("Tree is not empty");
        root = createNode(e, null, null, null);
        size = 1;
        return root;
    }
    public Position<E> addLeft(Position<E> p, E e)
            throws IllegalArgumentException {
        Node<E> parent = validate(p);
        if (parent.getLeft() != null)
            throw new IllegalArgumentException("p already has a left child");
        Node<E> child = createNode(e, parent, null, null);
        parent.setLeft(child);
        size++;
        return child;
    }
    public Position<E> addRight(Position<E> p, E e)
            throws IllegalArgumentException {
        Node<E> parent = validate(p);
        if (parent.getRight() != null)
            throw new IllegalArgumentException("p already has a right child");
        Node<E> child = createNode(e, parent, null, null);
        parent.setRight(child);
        size++;
        return child;
    }
    public E set(Position<E> p, E e) throws IllegalArgumentException {
        Node<E> node = validate(p);
        E temp = node.getElement();
        node.setElement(e);
        return temp;
    }
    public void attach(Position<E> p, LinkedBinaryTree<E> t1,
                       LinkedBinaryTree<E> t2) throws IllegalArgumentException {
        Node<E> node = validate(p);
        if (isInternal(p)) throw new IllegalArgumentException("p must be a leaf");
        size += t1.size() + t2.size();
        if (!t1.isEmpty()) {                  // attach t1 as left subtree of node
            t1.root.setParent(node);
            node.setLeft(t1.root);
            t1.root = null;
            t1.size = 0;
        }
        if (!t2.isEmpty()) {                  // attach t2 as right subtree of node
            t2.root.setParent(node);
            node.setRight(t2.root);
            t2.root = null;
            t2.size = 0;
        }
    }
    public E remove(Position<E> p) throws IllegalArgumentException {
        Node<E> node = validate(p);
        if (numChildren(p) == 2)
            throw new IllegalArgumentException("p has two children");
        Node<E> child = (node.getLeft() != null ? node.getLeft() : node.getRight() );
        if (child != null)
            child.setParent(node.getParent());  // child's grandparent becomes its parent
        if (node == root)
            root = child;                       // child becomes root
        else {
            Node<E> parent = node.getParent();
            if (node == parent.getLeft())
                parent.setLeft(child);
            else
                parent.setRight(child);
        }
        size--;
        E temp = node.getElement();
        node.setElement(null);                // help garbage collection
        node.setLeft(null);
        node.setRight(null);
        node.setParent(node);                 // our convention for defunct node
        return temp;
    }
}
public class ExpressionTree extends LinkedBinaryTree<String> {
    Stack<String> finalVer = new Stack<>();
    String infix;
    LinkedBinaryTree tree = new LinkedBinaryTree();
    Node first_node;
    static int temp = 0;
    private boolean isOperator(String token) {return token.equals("+") || token.equals("-") || token.equals("*") || token.equals("c") || token.equals("s");}
    private int getPriority(String operator) {
        return switch (operator) {
            case "+", "-" -> 1;
            case "*", "/" -> 2;
            case "c", "s" -> 3;
            default -> 0;
        };
    }

    //Constructor
    public ExpressionTree(String input) {
        infix = input;
        int paranthesis = 0;
        String[] arr = input.split(" ");
        String temp;
        for (String currentToken : arr) {
            if (currentToken.equals("(")) {
                paranthesis++;
            } else if (isOperator(currentToken)) {
                if (paranthesis == 1 && tree.isEmpty()) {
                    tree.addRoot(currentToken.charAt(0));
                }
                temp = getIndentation(paranthesis - 1) + currentToken;
                finalVer.push(temp);
            } else if (currentToken.equals("X")) {
                temp = getIndentation(paranthesis) + currentToken;
                finalVer.push(temp);
            } else if (isNumeric(currentToken)) {
                temp = getIndentation(paranthesis) + currentToken;
                finalVer.push(temp);
            } else if (currentToken.equals("cos")) {
                temp = getIndentation(paranthesis - 1) + currentToken;
                finalVer.push(temp);
            } else if (currentToken.equals(")")) {
                paranthesis--;
            }
        }
    }
    private String getIndentation(int count) {
        return ". ".repeat(Math.max(0, count));
    }
    private boolean isNumeric(String str) {return str.matches("-?\\d+(\\.\\d+)?");}
    public Node build(String s) {
        Stack<Node> nodeStack = new Stack<>();
        Stack<String> operatorStack = new Stack<>();
        Node leaf, leaf_1, leaf_2;

        for (int i = 0; i < s.length(); i++) {
            char ch = s.charAt(i);
            if (ch == '(') {
                operatorStack.push("(");
            } else if (Character.isDigit(ch)) {
                StringBuilder operand = new StringBuilder();
                operand.append(ch);

                while (i + 1 < s.length() && Character.isDigit(s.charAt(i + 1))) {
                    operand.append(s.charAt(i + 1));
                    i++;
                }

                leaf = new Node(operand.toString(), null, null, null);
                nodeStack.push(leaf);
            } else if (ch == 'X') {
                leaf = new Node("X", null, null, null);
                nodeStack.push(leaf);
            } else if (isOperator(String.valueOf(ch))) {
                String operator = String.valueOf(ch);

                while (!operatorStack.isEmpty() && !operatorStack.peek().equals("(") &&
                        getPriority(operatorStack.peek()) >= getPriority(operator)) {
                    String topOperator = operatorStack.pop();

                    if (topOperator.equals("c") || topOperator.equals("s")) {
                        leaf = new Node(topOperator, null, null, null);
                        leaf_1 = nodeStack.pop();
                        leaf.setRight(leaf_1);
                        leaf_1.setParent(leaf);
                        nodeStack.push(leaf);
                    } else {
                        leaf = new Node(topOperator, null, null, null);
                        leaf_1 = nodeStack.pop();
                        leaf_2 = nodeStack.pop();
                        leaf.setLeft(leaf_2);
                        leaf_2.setParent(leaf);
                        leaf.setRight(leaf_1);
                        leaf_1.setParent(leaf);
                        nodeStack.push(leaf);
                    }
                }
                operatorStack.push(operator);
                if (isTrig(operator)) {i += 2;}
            } else if (ch == ')') {
                while (!operatorStack.isEmpty() && !operatorStack.peek().equals("(")) {
                    String topOperator = operatorStack.pop();

                    if (!isTrig(topOperator)) {
                        leaf = new Node(topOperator, null, null, null);
                        leaf_1 = nodeStack.pop();
                        leaf_2 = nodeStack.pop();
                        leaf.setLeft(leaf_2);
                        leaf_2.setParent(leaf);
                        leaf.setRight(leaf_1);
                        leaf_1.setParent(leaf);
                        nodeStack.push(leaf);
                    } else {
                        leaf = new Node(topOperator, null, null, null);
                        leaf_1 = nodeStack.pop();
                        leaf.setRight(leaf_1);
                        leaf_1.setParent(leaf);
                        nodeStack.push(leaf);
                    }
                }
                operatorStack.pop();
            }
        }
        first_node = nodeStack.peek();
        first_node.setParent(first_node);
        return first_node;
    }

    //Recursive evaluate function
    public int evaluate(int xValue) {evaluate(xValue, first_node);return temp;}
    public void evaluate(int val, Node<String> node) {
        if (node == null) {return;}
        if (isTrig(node.getElement())) {
            if (node.getElement().equals("s")) {
                temp = (int) Math.sin(Math.toRadians(temp));
            } else if (node.getElement().equals("c")) {
                temp = (int) Math.cos(Math.toRadians(temp));
            }
            return;
        }else if (node.getElement().equals("X")) {
            temp = val;
            return;
        }

        char firstChar = node.getElement().charAt(0);
        if (firstChar >= '0' && firstChar <= '9') {
            temp = Integer.parseInt(node.getElement());
            return;
        }

        int computation_left = 0,computation_right = 0;
        evaluate(val, node.getLeft());
        computation_left = temp;
        evaluate(val, node.getRight());
        computation_right = temp;

        switch (node.getElement()) {
            case "+" -> temp = computation_left + computation_right;
            case "-" -> temp = computation_left - computation_right;
            case "*" -> temp = computation_left * computation_right;
        }
    }
    private boolean isTrig(String str){return str.equals("s")||str.equals("c");}

    //Recursive display function
    public void displayTree() {displayTree(first_node, 0);}
    private void displayTree(Node<String> node, int dep) {
        if (node == null) {return;}
        displayTree(node.getLeft(), dep + 1);
        int i = 0;
        while (i < dep) {System.out.print(". ");i++;}

        switch ((node.getElement()).charAt(0)) {
            case 's' -> System.out.println("sin");
            case 'c' -> System.out.println("cos");
            default -> System.out.println(node.getElement());
        }
        displayTree(node.getRight(), dep + 1);
    }
    public String toString(){return infix;}

    public static void main(String[] args){
        String input = " (X + (5*7))";
        ExpressionTree tree1 = new ExpressionTree(input);
        System.out.println(tree1.toString());
        tree1.build(input);
        tree1.displayTree();
        System.out.println("Answer:"+tree1.evaluate(4));
        System.out.println();

        String input2 = "((1+2)*(X+4))";
        ExpressionTree tree2 = new ExpressionTree(input);
        System.out.println(tree2.toString());
        tree2.build(input2);
        tree2.displayTree();
        System.out.println("Answer:"+tree2.evaluate(4));
        System.out.println();

    }
}

